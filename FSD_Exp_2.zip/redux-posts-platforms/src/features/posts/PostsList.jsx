import React, { useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import { fetchPosts, deletePost } from "./postsSlice";
import { selectPostsWithPlatforms } from "./selectors";

export default function PostsList() {
  const dispatch = useDispatch();
  const posts = useSelector(selectPostsWithPlatforms);
  const status = useSelector((state) => state.posts.status);

  useEffect(() => {
    if (status === "idle") dispatch(fetchPosts());
  }, [status, dispatch]);

  if (status === "loading") return <p>Loading posts…</p>;
  if (status === "failed") return <p>Couldn't load posts.</p>;
  if (posts.length === 0) return <p>No posts yet -- create one below.</p>;

  return (
    <ul style={{ listStyle: "none", padding: 0, display: "grid", gap: 10 }}>
      {posts.map((post) => (
        <li
          key={post.id}
          style={{ border: "1px solid #ddd", borderRadius: 8, padding: 12 }}
        >
          <div style={{ display: "flex", justifyContent: "space-between" }}>
            <strong>{post.title}</strong>
            <span
              style={{
                fontSize: 12,
                color: post.status === "published" ? "#2e7d32" : "#8a6d1f",
              }}
            >
              {post.status}
            </span>
          </div>
          <p style={{ margin: "6px 0", color: "#444" }}>{post.body}</p>
          <div style={{ display: "flex", gap: 6, flexWrap: "wrap" }}>
            {post.platforms.map((p) => (
              <span
                key={p.id}
                style={{
                  fontSize: 12,
                  background: "#eee",
                  borderRadius: 999,
                  padding: "2px 8px",
                }}
              >
                {p.name}
              </span>
            ))}
          </div>
          <button
            style={{ marginTop: 8 }}
            onClick={() => dispatch(deletePost(post.id))}
          >
            Delete
          </button>
        </li>
      ))}
    </ul>
  );
}
