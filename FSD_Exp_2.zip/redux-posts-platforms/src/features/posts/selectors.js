import { createSelector } from "@reduxjs/toolkit";
import { selectAllPosts } from "./postsSlice";
import { selectAllPlatforms } from "../platforms/platformsSlice";

// This is the payoff of normalizing: posts only store platform *ids*,
// so when platform data changes (name, connection status) every post
// referencing it is automatically up to date -- nothing to sync by hand.
// createSelector memoizes the join so it only recomputes when posts or
// platforms actually change, not on every render.
export const selectPostsWithPlatforms = createSelector(
  [selectAllPosts, selectAllPlatforms],
  (posts, platforms) => {
    const platformsById = Object.fromEntries(platforms.map((p) => [p.id, p]));
    return posts.map((post) => ({
      ...post,
      platforms: post.platformIds
        .map((id) => platformsById[id])
        .filter(Boolean),
    }));
  }
);
