import React, { useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import {
  fetchPlatforms,
  togglePlatformConnection,
  selectAllPlatforms,
} from "./platformsSlice";

export default function PlatformList() {
  const dispatch = useDispatch();
  const platforms = useSelector(selectAllPlatforms);
  const status = useSelector((state) => state.platforms.status);
  const pendingIds = useSelector((state) => state.platforms.pendingIds);

  // Guarding on `status === 'idle'` (rather than an empty-array check)
  // means a real fetch only ever fires once, even if this component
  // remounts -- other components can dispatch the same thunk without
  // triggering duplicate requests.
  useEffect(() => {
    if (status === "idle") dispatch(fetchPlatforms());
  }, [status, dispatch]);

  if (status === "loading") return <p>Loading platforms…</p>;
  if (status === "failed") return <p>Couldn't load platforms.</p>;

  return (
    <ul style={{ listStyle: "none", padding: 0, display: "grid", gap: 8 }}>
      {platforms.map((platform) => (
        <li
          key={platform.id}
          style={{
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center",
            border: "1px solid #ddd",
            borderRadius: 8,
            padding: "8px 12px",
          }}
        >
          <div>
            <strong>{platform.name}</strong>
            <div style={{ fontSize: 12, color: "#666" }}>
              {platform.charLimit} character limit
            </div>
          </div>
          <button
            onClick={() => dispatch(togglePlatformConnection(platform.id))}
            disabled={pendingIds[platform.id] === "pending"}
          >
            {pendingIds[platform.id] === "pending"
              ? "Updating…"
              : platform.connected
              ? "Connected"
              : "Connect"}
          </button>
        </li>
      ))}
    </ul>
  );
}
