# Posts & platforms -- Redux Toolkit state management

A centralized state management module for posts and the platforms they're
published to, built with Redux Toolkit and React-Redux.

## Setup

Inside a React app created with Vite or Create React App, copy the `src/`
files in this folder over your own `src/`, then install the two extra
dependencies:

```bash
npm install @reduxjs/toolkit react-redux
```

Then run the app as usual (`npm run dev` for Vite, `npm start` for CRA).

## How the state is organized

```
store
├── posts        (createEntityAdapter: { ids, entities })
│     each post: { id, title, body, platformIds: [...], status, createdAt }
└── platforms    (createEntityAdapter: { ids, entities })
      each platform: { id, name, connected, charLimit }
```

**Normalization**: a post does not embed platform objects -- it stores
`platformIds`, an array of ids. The platform's name, connection state, and
character limit live in exactly one place (`platforms`). When you need a
post together with its resolved platform details, that "join" happens in
`features/posts/selectors.js` (`selectPostsWithPlatforms`), memoized with
`createSelector` so it only recomputes when posts or platforms actually
change.

**Async flows**: `src/api/mockApi.js` is a stand-in backend -- every
function returns a Promise with ~500ms of latency and a small chance of
failure, so the `createAsyncThunk` calls in each slice have to handle
`pending` / `fulfilled` / `rejected`, not just an instant success path.
Swap the bodies of `mockApi` for real `fetch()` calls against a JSON
Server or real API later -- the slices and components don't change.

## File map

| File | Responsibility |
|---|---|
| `app/store.js` | Combines the two slices into one store |
| `api/mockApi.js` | Simulated backend for posts and platforms |
| `features/posts/postsSlice.js` | Posts reducer, thunks (fetch/create/update/delete) |
| `features/posts/selectors.js` | Memoized cross-slice selector (posts + platforms) |
| `features/posts/PostsList.jsx` | Displays posts, dispatches delete |
| `features/posts/PostEditor.jsx` | Form to create a post, dispatches create |
| `features/platforms/platformsSlice.js` | Platforms reducer, thunks (fetch/toggle) |
| `features/platforms/PlatformList.jsx` | Displays platforms, dispatches toggle |
| `App.jsx` / `index.js` | Wiring + the `<Provider store={store}>` root |

## Extending it

- Add a `PostEditor` "edit existing post" mode using `updatePost` and the
  `postEditedLocally` synchronous reducer for optimistic per-keystroke UI.
- Add persistence by calling `store.subscribe()` and writing the relevant
  slice(s) to `localStorage`, the way the standalone draft-manager module
  does -- or swap `mockApi` for real network calls entirely.
- Add Redux DevTools (already wired via `configureStore`) to watch actions
  and state diffs live in the browser extension.
