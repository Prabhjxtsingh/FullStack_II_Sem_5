import { useRef, useEffect } from "react";

// A way to *prove* a component did or didn't re-render, instead of just
// assuming. Incrementing a ref (not state) means counting a render never
// itself triggers another render. Logging happens in useEffect so the
// count printed matches what actually committed to the DOM. Watch the
// console while toggling a platform or filtering posts: rows unrelated
// to the change should stay on the same number.
export default function useRenderCount(label) {
  const countRef = useRef(0);
  countRef.current += 1;

  useEffect(() => {
    console.log(`[render] ${label}: #${countRef.current}`);
  });

  return countRef.current;
}
