import { configureStore } from "@reduxjs/toolkit";
import postsReducer from "../features/posts/postsSlice";
import platformsReducer from "../features/platforms/platformsSlice";

// This is the single source of truth for the app. Each slice owns one
// domain (posts, platforms) -- configureStore combines them and wires up
// Redux DevTools + the thunk middleware needed for createAsyncThunk,
// with no manual setup required (that's the "toolkit" boilerplate cut).
export const store = configureStore({
  reducer: {
    posts: postsReducer,
    platforms: platformsReducer,
  },
});

// Shape reference for JSDoc / mental model -- Redux Toolkit + JS doesn't
// enforce this, but it documents what `state` looks like everywhere:
//
// state = {
//   posts: {
//     ids: ['post-2', 'post-1'],
//     entities: { 'post-1': {...}, 'post-2': {...} },
//     status: 'succeeded', error: null,
//     mutationStatus: 'idle', mutationError: null,
//   },
//   platforms: {
//     ids: ['twitter', 'linkedin', 'instagram', 'mastodon'],
//     entities: { twitter: {...}, ... },
//     status: 'succeeded', error: null,
//     pendingIds: {},
//   },
// }
