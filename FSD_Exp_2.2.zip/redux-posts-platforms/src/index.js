import React from "react";
import { createRoot } from "react-dom/client";
import { Provider } from "react-redux";
import { store } from "./app/store";
import App from "./App";

// <Provider> makes the store available to every connected component
// below it via useSelector/useDispatch, without threading props through
// each level of the tree -- this is what removes the prop drilling.
const root = createRoot(document.getElementById("root"));
root.render(
  <Provider store={store}>
    <App />
  </Provider>
);
