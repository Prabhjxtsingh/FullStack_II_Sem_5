import React from "react";
import { useDispatch } from "react-redux";
import { togglePlatformConnection } from "./platformsSlice";
import useRenderCount from "../../hooks/useRenderCount";

// `postCount` is a plain number, so React.memo's default shallow
// comparison handles it correctly with no extra work: primitives
// compare by value, so this row only re-renders when its own count
// actually changed, even though the object the count came from
// (selectPlatformPostCounts' result) is a new reference every time any
// post changes anywhere in the app.
function PlatformRow({ platform, postCount, pending }) {
  const dispatch = useDispatch();
  const renderCount = useRenderCount(`PlatformRow:${platform.id}`);

  return (
    <li
      style={{
        display: "flex",
        justifyContent: "space-between",
        alignItems: "center",
        border: "1px solid #ddd",
        borderRadius: 8,
        padding: "8px 12px",
        listStyle: "none",
      }}
    >
      <div>
        <strong>{platform.name}</strong>
        <div style={{ fontSize: 12, color: "#666" }}>
          {platform.charLimit} character limit · {postCount} post{postCount === 1 ? "" : "s"}
        </div>
      </div>
      <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
        <button
          onClick={() => dispatch(togglePlatformConnection(platform.id))}
          disabled={pending}
        >
          {pending ? "Updating…" : platform.connected ? "Connected" : "Connect"}
        </button>
        <span style={{ fontSize: 11, color: "#999" }}>renders: {renderCount}</span>
      </div>
    </li>
  );
}

export default React.memo(PlatformRow);
