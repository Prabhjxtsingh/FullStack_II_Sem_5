import React, { useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import { fetchPlatforms, selectAllPlatforms } from "./platformsSlice";
import { selectPlatformPostCounts } from "../posts/selectors";
import PlatformRow from "./PlatformRow";
import useRenderCount from "../../hooks/useRenderCount";

export default function PlatformList() {
  const dispatch = useDispatch();
  const renderCount = useRenderCount("PlatformList");

  const platforms = useSelector(selectAllPlatforms);
  const status = useSelector((state) => state.platforms.status);
  const pendingIds = useSelector((state) => state.platforms.pendingIds);
  const postCounts = useSelector(selectPlatformPostCounts);

  useEffect(() => {
    if (status === "idle") dispatch(fetchPlatforms());
  }, [status, dispatch]);

  if (status === "loading") return <p>Loading platforms…</p>;
  if (status === "failed") return <p>Couldn't load platforms.</p>;

  return (
    <div>
      <ul style={{ padding: 0, display: "grid", gap: 8 }}>
        {platforms.map((platform) => (
          <PlatformRow
            key={platform.id}
            platform={platform}
            postCount={postCounts[platform.id] || 0}
            pending={pendingIds[platform.id] === "pending"}
          />
        ))}
      </ul>
      <p style={{ fontSize: 11, color: "#bbb" }}>PlatformList renders: {renderCount}</p>
    </div>
  );
}
