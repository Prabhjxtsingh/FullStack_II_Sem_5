import { createSlice, createAsyncThunk, createEntityAdapter } from "@reduxjs/toolkit";
import { platformsApi } from "../../api/mockApi";

// createEntityAdapter gives us a normalized shape automatically:
//   { ids: [...], entities: { [id]: platform } }
// instead of a plain array -- lookups by id become O(1), and updates
// don't require scanning/mapping the whole collection.
const platformsAdapter = createEntityAdapter();

const initialState = platformsAdapter.getInitialState({
  status: "idle", // idle | loading | succeeded | failed
  error: null,
  // per-id write state, so one platform toggling doesn't disable the
  // whole list -- e.g. { twitter: 'pending' }
  pendingIds: {},
});

export const fetchPlatforms = createAsyncThunk(
  "platforms/fetchPlatforms",
  async () => platformsApi.fetchAll()
);

export const togglePlatformConnection = createAsyncThunk(
  "platforms/toggleConnection",
  async (id) => platformsApi.toggleConnection(id)
);

const platformsSlice = createSlice({
  name: "platforms",
  initialState,
  reducers: {},
  extraReducers: (builder) => {
    builder
      .addCase(fetchPlatforms.pending, (state) => {
        state.status = "loading";
        state.error = null;
      })
      .addCase(fetchPlatforms.fulfilled, (state, action) => {
        state.status = "succeeded";
        platformsAdapter.setAll(state, action.payload);
      })
      .addCase(fetchPlatforms.rejected, (state, action) => {
        state.status = "failed";
        state.error = action.error.message;
      })

      .addCase(togglePlatformConnection.pending, (state, action) => {
        state.pendingIds[action.meta.arg] = "pending";
      })
      .addCase(togglePlatformConnection.fulfilled, (state, action) => {
        delete state.pendingIds[action.payload.id];
        platformsAdapter.upsertOne(state, action.payload);
      })
      .addCase(togglePlatformConnection.rejected, (state, action) => {
        delete state.pendingIds[action.meta.arg];
        state.error = action.error.message;
      });
  },
});

export default platformsSlice.reducer;

// ---- selectors ---------------------------------------------------------
// getSelectors() gives us selectAll / selectById / selectIds for free,
// pre-wired to this slice's location in the store.
export const {
  selectAll: selectAllPlatforms,
  selectById: selectPlatformById,
  selectIds: selectPlatformIds,
} = platformsAdapter.getSelectors((state) => state.platforms);

export const selectConnectedPlatforms = (state) =>
  selectAllPlatforms(state).filter((p) => p.connected);
