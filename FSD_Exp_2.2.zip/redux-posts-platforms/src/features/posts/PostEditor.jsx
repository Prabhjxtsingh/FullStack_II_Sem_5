import React, { useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { createPost } from "./postsSlice";
import { selectAllPlatforms } from "../platforms/platformsSlice";

export default function PostEditor() {
  const dispatch = useDispatch();
  const platforms = useSelector(selectAllPlatforms);
  const mutationStatus = useSelector((state) => state.posts.mutationStatus);
  const mutationError = useSelector((state) => state.posts.mutationError);

  const [title, setTitle] = useState("");
  const [body, setBody] = useState("");
  const [platformIds, setPlatformIds] = useState([]);

  const togglePlatform = (id) => {
    setPlatformIds((prev) =>
      prev.includes(id) ? prev.filter((p) => p !== id) : [...prev, id]
    );
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!title.trim()) return;
    const result = await dispatch(createPost({ title, body, platformIds }));
    if (createPost.fulfilled.match(result)) {
      setTitle("");
      setBody("");
      setPlatformIds([]);
    }
  };

  return (
    <form
      onSubmit={handleSubmit}
      style={{ display: "grid", gap: 8, border: "1px solid #ddd", borderRadius: 8, padding: 12 }}
    >
      <input
        placeholder="Post title"
        value={title}
        onChange={(e) => setTitle(e.target.value)}
      />
      <textarea
        placeholder="What do you want to say?"
        value={body}
        onChange={(e) => setBody(e.target.value)}
        rows={3}
      />
      <div style={{ display: "flex", gap: 10, flexWrap: "wrap" }}>
        {platforms.map((platform) => (
          <label key={platform.id} style={{ fontSize: 13 }}>
            <input
              type="checkbox"
              checked={platformIds.includes(platform.id)}
              onChange={() => togglePlatform(platform.id)}
            />{" "}
            {platform.name}
          </label>
        ))}
      </div>
      <button type="submit" disabled={mutationStatus === "loading"}>
        {mutationStatus === "loading" ? "Saving…" : "Create post"}
      </button>
      {mutationStatus === "failed" && (
        <p style={{ color: "#b3261e", fontSize: 13 }}>{mutationError}</p>
      )}
    </form>
  );
}
