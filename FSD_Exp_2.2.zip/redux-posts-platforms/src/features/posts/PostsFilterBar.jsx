import React from "react";
import useRenderCount from "../../hooks/useRenderCount";

// Pure presentational component: every value it needs comes in as props,
// nothing is read from the store directly. Combined with React.memo,
// that means it only re-renders when the filter values themselves
// change or the platform list changes -- not whenever a post is added,
// edited, or deleted, since those don't affect any prop this component
// actually reads.
function PostsFilterBar({
  platforms,
  searchTerm,
  statusFilter,
  platformId,
  onSearchTermChange,
  onStatusFilterChange,
  onPlatformIdChange,
}) {
  const renderCount = useRenderCount("PostsFilterBar");

  return (
    <div style={{ display: "flex", gap: 8, marginBottom: 10, flexWrap: "wrap" }}>
      <input
        placeholder="Search title or body"
        value={searchTerm}
        onChange={(e) => onSearchTermChange(e.target.value)}
        style={{ flex: 1, minWidth: 160 }}
      />
      <select value={statusFilter} onChange={(e) => onStatusFilterChange(e.target.value)}>
        <option value="all">All statuses</option>
        <option value="draft">Draft</option>
        <option value="published">Published</option>
      </select>
      <select value={platformId} onChange={(e) => onPlatformIdChange(e.target.value)}>
        <option value="all">All platforms</option>
        {platforms.map((p) => (
          <option key={p.id} value={p.id}>
            {p.name}
          </option>
        ))}
      </select>
      <span style={{ fontSize: 11, color: "#bbb", alignSelf: "center" }}>
        renders: {renderCount}
      </span>
    </div>
  );
}

export default React.memo(PostsFilterBar);
