import { createSlice, createAsyncThunk, createEntityAdapter } from "@reduxjs/toolkit";
import { postsApi } from "../../api/mockApi";

// Posts are normalized the same way as platforms. Each post stores
// `platformIds` (an array of platform id strings) rather than embedding
// full platform objects -- this is the normalization the lab asks for:
// one source of truth per platform, referenced by id from posts,
// so a platform's name/connection state never needs to be updated in
// more than one place.
const postsAdapter = createEntityAdapter({
  sortComparer: (a, b) => new Date(b.createdAt) - new Date(a.createdAt),
});

const initialState = postsAdapter.getInitialState({
  status: "idle", // idle | loading | succeeded | failed
  error: null,
  mutationStatus: "idle", // tracks create/update/delete instead of the initial load
  mutationError: null,
});

export const fetchPosts = createAsyncThunk("posts/fetchPosts", async () =>
  postsApi.fetchAll()
);

export const createPost = createAsyncThunk("posts/createPost", async (input) =>
  postsApi.create(input)
);

export const updatePost = createAsyncThunk(
  "posts/updatePost",
  async ({ id, changes }) => postsApi.update(id, changes)
);

export const deletePost = createAsyncThunk("posts/deletePost", async (id) =>
  postsApi.remove(id)
);

const postsSlice = createSlice({
  name: "posts",
  initialState,
  reducers: {
    // A synchronous local-only update, useful for optimistic UI (e.g. a
    // draft body edited on every keystroke shouldn't hit the network on
    // every keystroke) -- persisted separately via updatePost when the
    // user actually saves.
    postEditedLocally(state, action) {
      const { id, changes } = action.payload;
      postsAdapter.upsertOne(state, { ...state.entities[id], ...changes });
    },
  },
  extraReducers: (builder) => {
    builder
      // --- initial load ---
      .addCase(fetchPosts.pending, (state) => {
        state.status = "loading";
        state.error = null;
      })
      .addCase(fetchPosts.fulfilled, (state, action) => {
        state.status = "succeeded";
        postsAdapter.setAll(state, action.payload);
      })
      .addCase(fetchPosts.rejected, (state, action) => {
        state.status = "failed";
        state.error = action.error.message;
      })

      // --- create ---
      .addCase(createPost.pending, (state) => {
        state.mutationStatus = "loading";
        state.mutationError = null;
      })
      .addCase(createPost.fulfilled, (state, action) => {
        state.mutationStatus = "succeeded";
        postsAdapter.addOne(state, action.payload);
      })
      .addCase(createPost.rejected, (state, action) => {
        state.mutationStatus = "failed";
        state.mutationError = action.error.message;
      })

      // --- update ---
      .addCase(updatePost.fulfilled, (state, action) => {
        postsAdapter.upsertOne(state, action.payload);
      })
      .addCase(updatePost.rejected, (state, action) => {
        state.mutationError = action.error.message;
      })

      // --- delete ---
      .addCase(deletePost.fulfilled, (state, action) => {
        postsAdapter.removeOne(state, action.payload);
      })
      .addCase(deletePost.rejected, (state, action) => {
        state.mutationError = action.error.message;
      });
  },
});

export const { postEditedLocally } = postsSlice.actions;
export default postsSlice.reducer;

// ---- selectors ---------------------------------------------------------
export const {
  selectAll: selectAllPosts,
  selectById: selectPostById,
  selectIds: selectPostIds,
} = postsAdapter.getSelectors((state) => state.posts);

export const selectPostsByStatus = (status) => (state) =>
  selectAllPosts(state).filter((p) => p.status === status);
