import React from "react";
import { useDispatch } from "react-redux";
import { deletePost } from "./postsSlice";
import useRenderCount from "../../hooks/useRenderCount";

// Dispatch is pulled in locally rather than passed as an `onDelete` prop.
// That sidesteps a common way React.memo gets defeated by accident: an
// inline arrow function passed from the parent (`onClick={() =>
// dispatch(...)}`) is a new reference every parent render, which alone
// would force this row to re-render even with React.memo -- because
// useDispatch() itself is referentially stable, there's no unstable
// prop to worry about here.
function PostRow({ post }) {
  const dispatch = useDispatch();
  const renderCount = useRenderCount(`PostRow:${post.id}`);

  return (
    <li
      style={{
        border: "1px solid #ddd",
        borderRadius: 8,
        padding: 12,
        listStyle: "none",
      }}
    >
      <div style={{ display: "flex", justifyContent: "space-between" }}>
        <strong>{post.title}</strong>
        <span
          style={{
            fontSize: 12,
            color: post.status === "published" ? "#2e7d32" : "#8a6d1f",
          }}
        >
          {post.status}
        </span>
      </div>

      <p style={{ margin: "6px 0", color: "#444" }}>{post.body}</p>

      <div style={{ display: "flex", gap: 6, flexWrap: "wrap", alignItems: "center" }}>
        {post.platforms.map((p) => (
          <span
            key={p.id}
            style={{ fontSize: 12, background: "#eee", borderRadius: 999, padding: "2px 8px" }}
          >
            {p.name}
          </span>
        ))}
      </div>

      <div style={{ display: "flex", justifyContent: "space-between", marginTop: 8 }}>
        <button onClick={() => dispatch(deletePost(post.id))}>Delete</button>
        <span style={{ fontSize: 11, color: "#999" }}>renders: {renderCount}</span>
      </div>
    </li>
  );
}

// React.memo's default shallow comparison checks `prevProps.post ===
// nextProps.post`. That comparison is only meaningful because
// selectPostsWithPlatforms preserves that reference across unrelated
// recomputations (see createArrayItemMemoizer) -- without that,
// React.memo here would be a no-op, since `post` would be a new object
// on every store update regardless of whether *this* post changed.
export default React.memo(PostRow);
