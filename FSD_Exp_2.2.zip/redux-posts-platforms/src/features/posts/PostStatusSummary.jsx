import React from "react";
import { useSelector } from "react-redux";
import { selectPostCountsByStatus } from "./selectors";
import useRenderCount from "../../hooks/useRenderCount";

// A tiny dashboard built entirely from derived state -- nothing here is
// stored directly, it's all computed from the same `posts` state the
// list itself reads. Wrapped in React.memo mainly to make a point: this
// component's only prop-like input is the selector result, so it only
// re-renders when selectPostCountsByStatus's memoized output reference
// actually changes -- e.g. deleting or creating a post, but not when an
// unrelated platform is toggled.
function PostStatusSummary() {
  const counts = useSelector(selectPostCountsByStatus);
  const renderCount = useRenderCount("PostStatusSummary");

  const entries = Object.entries(counts);

  return (
    <div
      style={{
        display: "flex",
        gap: 12,
        alignItems: "center",
        fontSize: 13,
        color: "#555",
        marginBottom: 10,
      }}
    >
      {entries.length === 0 && <span>No posts yet.</span>}
      {entries.map(([status, count]) => (
        <span
          key={status}
          style={{ background: "#f0f0f0", borderRadius: 999, padding: "3px 10px" }}
        >
          {status}: {count}
        </span>
      ))}
      <span style={{ marginLeft: "auto", fontSize: 11, color: "#bbb" }}>
        renders: {renderCount}
      </span>
    </div>
  );
}

export default React.memo(PostStatusSummary);
