import { createSelector } from "@reduxjs/toolkit";
import { selectAllPosts } from "./postsSlice";
import { selectAllPlatforms } from "../platforms/platformsSlice";
import { createArrayItemMemoizer } from "../../utils/createArrayItemMemoizer";

// ---------------------------------------------------------------------
// 1. Basic derived state -- a memoized join
// ---------------------------------------------------------------------
// Posts only store platformIds; this resolves each id to its full
// platform object. createSelector means the join only re-runs when
// selectAllPosts or selectAllPlatforms actually produced a new
// reference (i.e. something in one of those slices really changed) --
// not on every render of every component that reads it.
const mapPostsWithItemMemo = createArrayItemMemoizer();

export const selectPostsWithPlatforms = createSelector(
  [selectAllPosts, selectAllPlatforms],
  (posts, platforms) => {
    const platformsById = Object.fromEntries(platforms.map((p) => [p.id, p]));

    return mapPostsWithItemMemo(
      posts,
      (post) => post.id,
      // Dependency list for this one post: its own reference, plus the
      // resolved platform object references it depends on. If none of
      // these changed since last time, the previous merged object is
      // reused as-is -- same reference, so React.memo on a row reading
      // it will correctly skip re-rendering.
      (post) => [post, ...post.platformIds.map((id) => platformsById[id])],
      (post) => ({
        ...post,
        platforms: post.platformIds.map((id) => platformsById[id]).filter(Boolean),
      })
    );
  }
);

// ---------------------------------------------------------------------
// 2. Grouped / aggregated derived data
// ---------------------------------------------------------------------
// Counts by status (draft vs. published) -- a small dashboard-style
// summary computed from existing state rather than tracked separately
// (which would risk drifting out of sync with the actual posts).
export const selectPostCountsByStatus = createSelector([selectAllPosts], (posts) =>
  posts.reduce((counts, post) => {
    counts[post.status] = (counts[post.status] || 0) + 1;
    return counts;
  }, {})
);

// How many posts target each platform -- feeds a badge on PlatformRow.
// Built from selectPostsWithPlatforms (already memoized), so this only
// recomputes when the joined data itself actually changed.
export const selectPlatformPostCounts = createSelector(
  [selectPostsWithPlatforms],
  (posts) =>
    posts.reduce((counts, post) => {
      post.platforms.forEach((platform) => {
        counts[platform.id] = (counts[platform.id] || 0) + 1;
      });
      return counts;
    }, {})
);

// Posts grouped by the platform they're published to (a post with
// multiple platforms appears in more than one group) -- the kind of
// "reshape for a different view" derived data that's cheap to compute
// on read and would be wasteful to store as its own piece of state.
export const selectPostsGroupedByPlatform = createSelector(
  [selectPostsWithPlatforms],
  (posts) => {
    const groups = {};
    posts.forEach((post) => {
      post.platforms.forEach((platform) => {
        if (!groups[platform.id]) groups[platform.id] = [];
        groups[platform.id].push(post);
      });
    });
    return groups;
  }
);

// ---------------------------------------------------------------------
// 3. Parameterized selector -- the factory pattern
// ---------------------------------------------------------------------
// A single module-level `createSelector` instance only remembers its
// *last* call. If two components filtered by different search terms
// both called one shared `selectFilteredPosts(state, filters)`, every
// render would alternate which filters it was called with, the cache
// would never match twice in a row, and memoization would do nothing.
//
// The fix: export a *factory function* instead of a selector. Each
// component that needs filtering calls makeSelectFilteredPosts() once
// (via useMemo, so it's created exactly once per component instance)
// to get its own selector with its own private cache.
export function makeSelectFilteredPosts() {
  return createSelector(
    [selectPostsWithPlatforms, (state, filters) => filters],
    (posts, filters) => {
      const { searchTerm = "", statusFilter = "all", platformId = "all" } = filters;
      const term = searchTerm.trim().toLowerCase();

      return posts.filter((post) => {
        const matchesTerm =
          !term ||
          post.title.toLowerCase().includes(term) ||
          post.body.toLowerCase().includes(term);
        const matchesStatus = statusFilter === "all" || post.status === statusFilter;
        const matchesPlatform =
          platformId === "all" || post.platforms.some((p) => p.id === platformId);
        return matchesTerm && matchesStatus && matchesPlatform;
      });
    }
  );
}
