import React, { useEffect, useMemo, useState, useCallback } from "react";
import { useDispatch, useSelector } from "react-redux";
import { fetchPosts } from "./postsSlice";
import { selectAllPlatforms } from "../platforms/platformsSlice";
import { makeSelectFilteredPosts } from "./selectors";
import PostRow from "./PostRow";
import PostsFilterBar from "./PostsFilterBar";
import PostStatusSummary from "./PostStatusSummary";
import useRenderCount from "../../hooks/useRenderCount";

export default function PostsList() {
  const dispatch = useDispatch();
  const renderCount = useRenderCount("PostsList");

  const status = useSelector((state) => state.posts.status);
  const platforms = useSelector(selectAllPlatforms);

  const [searchTerm, setSearchTerm] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const [platformId, setPlatformId] = useState("all");

  useEffect(() => {
    if (status === "idle") dispatch(fetchPosts());
  }, [status, dispatch]);

  // Created once per component instance, not once per render: calling
  // makeSelectFilteredPosts() directly inside useSelector would build a
  // brand-new selector (with a cold, empty cache) on every render,
  // which never memoizes anything. useMemo with an empty dependency
  // array is what makes this "once per mount".
  const selectFilteredPosts = useMemo(() => makeSelectFilteredPosts(), []);

  // Bundled into one object so the selector's second input arg has a
  // single stable-when-unchanged reference instead of three separate
  // primitives -- createSelector compares this whole object by
  // reference, so it must only change when a filter value actually does.
  const filters = useMemo(
    () => ({ searchTerm, statusFilter, platformId }),
    [searchTerm, statusFilter, platformId]
  );

  const posts = useSelector((state) => selectFilteredPosts(state, filters));

  // Stable references so PostsFilterBar's React.memo isn't defeated by
  // a freshly-created handler on every PostsList render.
  const handleSearchTermChange = useCallback((value) => setSearchTerm(value), []);
  const handleStatusFilterChange = useCallback((value) => setStatusFilter(value), []);
  const handlePlatformIdChange = useCallback((value) => setPlatformId(value), []);

  if (status === "loading") return <p>Loading posts…</p>;
  if (status === "failed") return <p>Couldn't load posts.</p>;

  return (
    <div>
      <PostStatusSummary />

      <PostsFilterBar
        platforms={platforms}
        searchTerm={searchTerm}
        statusFilter={statusFilter}
        platformId={platformId}
        onSearchTermChange={handleSearchTermChange}
        onStatusFilterChange={handleStatusFilterChange}
        onPlatformIdChange={handlePlatformIdChange}
      />

      {posts.length === 0 ? (
        <p>No posts match these filters.</p>
      ) : (
        <ul style={{ padding: 0, display: "grid", gap: 10 }}>
          {posts.map((post) => (
            <PostRow key={post.id} post={post} />
          ))}
        </ul>
      )}

      <p style={{ fontSize: 11, color: "#bbb" }}>PostsList renders: {renderCount}</p>
    </div>
  );
}
