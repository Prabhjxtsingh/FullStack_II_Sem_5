// Reselect's createSelector memoizes the *call*: same input references
// in -> the same output reference out, with no recomputation in between.
// But if the selector body builds its result with `.map()`, every item
// in that mapped array is a brand-new object each time the body actually
// runs -- even for items whose own underlying data didn't change at all.
// A new object reference is all React.memo() needs to decide a row must
// re-render, so without this, wrapping a row component in React.memo
// buys nothing: every recompute still hands every row a "new" prop.
//
// This keeps a small cache keyed by id. On each run, an item only gets a
// freshly computed value if its own dependency list changed; otherwise
// the previous reference is reused, so React.memo can correctly bail out
// for the rows that weren't actually affected.
export function createArrayItemMemoizer() {
  let cache = new Map(); // id -> { deps: unknown[], value: unknown }

  return function mapWithItemMemo(items, getId, getDeps, compute) {
    const nextCache = new Map();

    const result = items.map((item) => {
      const id = getId(item);
      const deps = getDeps(item);
      const previous = cache.get(id);

      const depsUnchanged =
        previous &&
        previous.deps.length === deps.length &&
        previous.deps.every((dep, i) => dep === deps[i]);

      const value = depsUnchanged ? previous.value : compute(item);
      nextCache.set(id, { deps, value });
      return value;
    });

    cache = nextCache; // drop entries for ids that no longer exist
    return result;
  };
}
