// A stand-in backend. Every function returns a Promise with artificial
// latency and an occasional simulated failure, so the async thunks that
// call it exercise real pending/fulfilled/rejected states -- not just
// instant resolution. Swap the bodies for real fetch() calls later;
// the thunks and slices don't need to change.

const LATENCY_MS = 500;
const FAILURE_RATE = 0.1;

const delay = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

function maybeFail(label) {
  if (Math.random() < FAILURE_RATE) {
    throw new Error(`${label} failed -- request timed out.`);
  }
}

// ---- in-memory "database" -------------------------------------------
let platforms = [
  { id: "twitter", name: "Twitter / X", connected: true, charLimit: 280 },
  { id: "linkedin", name: "LinkedIn", connected: true, charLimit: 3000 },
  { id: "instagram", name: "Instagram", connected: false, charLimit: 2200 },
  { id: "mastodon", name: "Mastodon", connected: false, charLimit: 500 },
];

let posts = [
  {
    id: "post-1",
    title: "Launch week recap",
    body: "Three features shipped, zero rollbacks. Onward.",
    platformIds: ["twitter", "linkedin"],
    status: "published",
    createdAt: new Date(Date.now() - 86400000).toISOString(),
  },
  {
    id: "post-2",
    title: "Behind the scenes",
    body: "Draft: a short thread about how the design system evolved.",
    platformIds: ["twitter"],
    status: "draft",
    createdAt: new Date().toISOString(),
  },
];

let nextPostId = 3;

// ---- platforms endpoints ---------------------------------------------
export const platformsApi = {
  async fetchAll() {
    await delay(LATENCY_MS);
    maybeFail("Loading platforms");
    return platforms.map((p) => ({ ...p }));
  },

  async toggleConnection(id) {
    await delay(LATENCY_MS);
    maybeFail("Updating platform connection");
    platforms = platforms.map((p) =>
      p.id === id ? { ...p, connected: !p.connected } : p
    );
    return platforms.find((p) => p.id === id);
  },
};

// ---- posts endpoints ---------------------------------------------------
export const postsApi = {
  async fetchAll() {
    await delay(LATENCY_MS);
    maybeFail("Loading posts");
    return posts.map((p) => ({ ...p }));
  },

  async create(input) {
    await delay(LATENCY_MS);
    maybeFail("Creating post");
    const post = {
      id: `post-${nextPostId++}`,
      title: input.title,
      body: input.body,
      platformIds: input.platformIds || [],
      status: "draft",
      createdAt: new Date().toISOString(),
    };
    posts = [post, ...posts];
    return post;
  },

  async update(id, changes) {
    await delay(LATENCY_MS);
    maybeFail("Updating post");
    let updated = null;
    posts = posts.map((p) => {
      if (p.id !== id) return p;
      updated = { ...p, ...changes };
      return updated;
    });
    if (!updated) throw new Error("Post not found");
    return updated;
  },

  async remove(id) {
    await delay(LATENCY_MS);
    maybeFail("Deleting post");
    posts = posts.filter((p) => p.id !== id);
    return id;
  },
};
