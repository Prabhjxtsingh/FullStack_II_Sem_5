import React from "react";
import PlatformList from "./features/platforms/PlatformList";
import PostsList from "./features/posts/PostsList";
import PostEditor from "./features/posts/PostEditor";

export default function App() {
  return (
    <div style={{ maxWidth: 640, margin: "0 auto", padding: 24, fontFamily: "sans-serif" }}>
      <h1>Posts & platforms</h1>

      <section style={{ marginBottom: 32 }}>
        <h2>Platforms</h2>
        <PlatformList />
      </section>

      <section style={{ marginBottom: 32 }}>
        <h2>New post</h2>
        <PostEditor />
      </section>

      <section>
        <h2>Posts</h2>
        <PostsList />
      </section>
    </div>
  );
}
