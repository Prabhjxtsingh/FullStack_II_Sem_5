# Optimizing selectors & rendering

This builds on the Redux Toolkit posts/platforms store from the previous
module. Nothing in the store shape changed -- this adds a layer of
memoized derived state on top of it, plus render-level optimizations in
the components that read it.

## 1. Derived state, three ways

All defined in `src/features/posts/selectors.js`, all built with
`createSelector` (re-exported by Redux Toolkit from Reselect) so each one
only recomputes when its actual inputs change:

- **Join** -- `selectPostsWithPlatforms` resolves each post's
  `platformIds` into full platform objects. This is state that could
  have been stored pre-joined on every post, but that would mean two
  copies of platform data to keep in sync; deriving it on read means
  there's exactly one source of truth.
- **Aggregation** -- `selectPostCountsByStatus` and
  `selectPlatformPostCounts` reduce the post list into small summary
  objects (counts by status, counts per platform). Neither is stored
  state; both are computed from `posts` whenever it's read.
- **Regrouping** -- `selectPostsGroupedByPlatform` reshapes the same
  data into `{ [platformId]: Post[] }`, for a per-platform view, without
  duplicating any post.

## 2. The parameterized-selector problem

`makeSelectFilteredPosts` is a **factory function**, not a selector.
Filtering needs an argument (the current search term / status /
platform), and a single shared `createSelector` instance only caches its
*most recent* call -- if the search term changes on every keystroke, the
cache would miss every single time and buy nothing.

The fix used in `PostsList.jsx`:

```js
const selectFilteredPosts = useMemo(() => makeSelectFilteredPosts(), []);
```

`useMemo(..., [])` creates the selector exactly once per component
instance, giving it its own private cache that only ever sees this
component's filter changes.

## 3. Why React.memo alone wasn't enough

`PostRow` and `PlatformRow` are wrapped in `React.memo`, which skips
re-rendering a component if its props are shallowly equal to last time.
That only works if unrelated updates don't hand the row a *new* object
reference for props that didn't actually change.

`selectAllPosts` / `selectAllPlatforms` (from `createEntityAdapter`) are
already reference-stable this way. But `selectPostsWithPlatforms` builds
its result with `.map()`, and a plain `.map()` allocates a new merged
object for *every* post every time the join re-runs -- including posts
whose data didn't change. `src/utils/createArrayItemMemoizer.js` fixes
this: it caches each item by id and only computes a new one when that
item's own dependencies changed, reusing the previous reference
otherwise. That's what makes `React.memo` on `PostRow` actually
effective -- toggling one platform's connection re-runs the join (since
`selectAllPlatforms`'s reference changed), but only posts that reference
that platform get new objects; every other `PostRow` keeps the same
`post` prop reference and skips re-rendering.

`PlatformRow`'s `postCount` prop didn't need this treatment -- it's a
plain number, and numbers compare correctly by value regardless of what
object they came from.

## 4. Observing it

Every list-adjacent component (`PostsList`, `PostRow`, `PlatformList`,
`PlatformRow`, `PostsFilterBar`, `PostStatusSummary`) calls
`useRenderCount(label)` (`src/hooks/useRenderCount.js`) and shows a small
"renders: N" badge. Open the browser console (it also logs there) and:

- Toggle one platform's connection -- only that `PlatformRow`'s count
  should climb, plus `PlatformList` (the container) and any `PostRow`
  whose post targets that platform. Unrelated `PostRow`s should hold.
- Type in the search box -- only `PostsList` and the rows currently
  matching should climb; `PostsFilterBar` climbs once per keystroke
  (it owns the input), `PostStatusSummary` shouldn't move at all, since
  filtering doesn't change how many posts exist per status.
- Delete a post -- `PostStatusSummary`'s count should climb (the
  aggregate changed), but rows for posts that weren't deleted shouldn't.

## 5. Where useCallback comes in

`PostsFilterBar` is a memoized, purely presentational component --
worth keeping cheap since it re-renders on every keystroke anyway. The
`onSearchTermChange` / `onStatusFilterChange` / `onPlatformIdChange`
handlers passed to it are wrapped in `useCallback` in `PostsList`, so
`PostsFilterBar`'s props stay reference-stable across `PostsList`
re-renders it isn't actually related to (e.g. a post being deleted).

`PostRow` and `PlatformRow` dispatch directly via their own
`useDispatch()` rather than taking an `onDelete`/`onToggle` prop --
sidestepping the same problem a different way: there's no
parent-provided callback to accidentally destabilize in the first place.
